package com.example.datakelinci

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Rabbit(
    val name: String,
    val type: String,
    val age: String,
    val photo: String = "",
    val gender: String = ""
)

data class Mating(
    val mother: String,
    val father: String,
    val matingDate: String,
    val birthDate: String,
    val babies: Int
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DataKelinciApp() }
    }
}

@Composable
fun DataKelinciApp() {
    var screen by remember { mutableStateOf("home") }
    var selectedRabbit by remember { mutableStateOf<Rabbit?>(null) }

    val mothers = remember { mutableStateListOf<Rabbit>() }
    val fathers = remember { mutableStateListOf<Rabbit>() }
    val matings = remember { mutableStateListOf<Mating>() }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF059669),
            secondary = Color(0xFF10B981),
            background = Color(0xFFF7FAF8)
        )
    ) {
        Scaffold(
            topBar = {
                if (screen != "home") {
                    TopAppBar(
                        title = { Text(titleFor(screen)) },
                        navigationIcon = {
                            IconButton({ screen = "home" }) {
                                Icon(Icons.Default.ArrowBack, "Kembali")
                            }
                        }
                    )
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when {
                    selectedRabbit != null -> RabbitDetail(selectedRabbit!!) { selectedRabbit = null }
                    screen == "home" -> Home(
                        mothers.size, fathers.size, matings.size,
                        onMothers = { screen = "mothers" },
                        onFathers = { screen = "fathers" },
                        onMatings = { screen = "matings" }
                    )
                    screen == "mothers" -> RabbitList("Indukan", mothers) { selectedRabbit = it }
                    screen == "fathers" -> RabbitList("Pejantan", fathers) { selectedRabbit = it }
                    screen == "matings" -> MatingList(matings)
                }
            }
        }
    }
}

fun titleFor(screen: String) = when(screen) {
    "mothers" -> "Indukan"
    "fathers" -> "Pejantan"
    "matings" -> "Perkawinan"
    else -> "Data Kelinci"
}

@Composable
fun Home(mothers: Int, fathers: Int, matings: Int, onMothers: () -> Unit, onFathers: () -> Unit, onMatings: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Color(0xFFF7FAF8)).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(18.dp))
        Text("🐇", fontSize = 64.sp)
        Text("Data Kelinci", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color(0xFF064E3B))
        Text("Kelola data ternak dengan mudah", color = Color.Gray)
        Spacer(Modifier.height(28.dp))
        MenuCard("🐰", "Indukan", "$mothers data", onMothers, Color(0xFF059669))
        MenuCard("🐇", "Pejantan", "$fathers data", onFathers, Color(0xFF2563EB))
        MenuCard("❤️", "Perkawinan", "$matings data", onMatings, Color(0xFFE11D48))
        Spacer(Modifier.weight(1f))
        Text("Data Kelinci • v1.0", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun MenuCard(icon: String, title: String, count: String, click: () -> Unit, color: Color) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 7.dp).clickable { click() },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = color)
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 30.sp)
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(count, color = Color.White.copy(alpha = .8f))
            }
            Icon(Icons.Default.ChevronRight, null, tint = Color.White)
        }
    }
}

@Composable
fun RabbitList(title: String, rabbits: List<Rabbit>, onClick: (Rabbit) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Daftar $title", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        if (rabbits.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Belum ada data. Tambahkan data kelinci.", color = Color.Gray)
            }
        } else {
            LazyColumn {
                items(rabbits) { rabbit ->
                    Card(
                        Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { onClick(rabbit) },
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(58.dp).background(Color(0xFFE5F5ED), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) { Text("🐇", fontSize = 30.sp) }
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(rabbit.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                Text("${rabbit.type} • ${rabbit.age}", color = Color.Gray)
                            }
                            Icon(Icons.Default.ChevronRight, null)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RabbitDetail(rabbit: Rabbit, back: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Box(
            Modifier.fillMaxWidth().height(230.dp)
                .background(Color(0xFFE5F5ED), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) { Text("🐇", fontSize = 100.sp) }
        Spacer(Modifier.height(18.dp))
        Text(rabbit.name, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        InfoRow("Jenis", rabbit.type)
        InfoRow("Usia", rabbit.age)
        if (rabbit.gender.isNotBlank()) InfoRow("Kelamin", rabbit.gender)
        Spacer(Modifier.height(18.dp))
        Button(onClick = back, Modifier.fillMaxWidth()) { Text("Kembali") }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 9.dp)) {
        Text(label, Modifier.weight(1f), color = Color.Gray)
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun MatingList(matings: List<Mating>) {
    if (matings.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Belum ada data perkawinan.", color = Color.Gray)
        }
    } else {
        LazyColumn(Modifier.padding(16.dp)) {
            items(matings) { m ->
                Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("${m.mother} × ${m.father}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Tanggal kawin: ${m.matingDate}")
                        Text("Tanggal lahir: ${m.birthDate}")
                        Text("Jumlah anakan: ${m.babies} ekor")
                    }
                }
            }
        }
    }
}
