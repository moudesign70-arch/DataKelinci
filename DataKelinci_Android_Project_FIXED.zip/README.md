# Data Kelinci — Android

Project awal aplikasi Android untuk pencatatan ternak kelinci.

## Fitur versi 1
- Home
- Indukan
- Pejantan
- Perkawinan
- Detail kelinci saat nama diklik
- Struktur data sudah dipisahkan untuk dikembangkan ke database
- Logo aplikasi disertakan

## Membuka project
Buka folder ini di Android Studio, tunggu Gradle Sync, lalu jalankan pada emulator/HP Android.

## Pengembangan berikutnya
Versi ini adalah fondasi UI/prototype. Tahap berikutnya dapat menambahkan Room Database, form tambah/edit/hapus, pemilih foto dari galeri/kamera, data anakan per perkawinan, pencarian, backup, dan export.
