# Data Kelinci
Project Android Kotlin + Jetpack Compose + Material 3 + Room + Navigation Compose.
Package: `com.example.datakelinci`, minSdk 24.

Build:
`./gradlew assembleDebug`

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

GitHub Actions menghasilkan artifact `DataKelinci-APK` dan menamainya `DataKelinci.apk`.
