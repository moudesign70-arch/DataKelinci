package com.example.datakelinci.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface RabbitDao {
    @Query("SELECT * FROM rabbits WHERE gender = :gender ORDER BY id DESC") fun byGender(gender: String): Flow<List<Rabbit>>
    @Query("SELECT COUNT(*) FROM rabbits") fun countAll(): Flow<Int>
    @Query("SELECT COUNT(*) FROM rabbits WHERE gender='Indukan'") fun countFemale(): Flow<Int>
    @Query("SELECT COUNT(*) FROM rabbits WHERE gender='Pejantan'") fun countMale(): Flow<Int>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(r: Rabbit)
    @Update suspend fun update(r: Rabbit)
    @Delete suspend fun delete(r: Rabbit)
}
@Dao
interface MatingDao {
    @Query("SELECT * FROM matings ORDER BY id DESC") fun all(): Flow<List<Mating>>
    @Query("SELECT COUNT(*) FROM matings") fun countAll(): Flow<Int>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(m: Mating)
    @Delete suspend fun delete(m: Mating)
}
