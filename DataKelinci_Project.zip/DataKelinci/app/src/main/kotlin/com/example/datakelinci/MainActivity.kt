package com.example.datakelinci

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*
import com.example.datakelinci.data.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App(AppDatabase.get(this)) }
    }
}

@Composable
fun App(db: AppDatabase) {
    val nav = rememberNavController()
    Scaffold(bottomBar = {
        NavigationBar {
            listOf("home" to "Home", "female" to "Indukan", "male" to "Pejantan", "mating" to "Perkawinan").forEach { (route, label) ->
                NavigationBarItem(
                    selected = nav.currentBackStackEntryAsState().value?.destination?.route == route,
                    onClick = { nav.navigate(route) { launchSingleTop = true } },
                    icon = { Text("●") }, label = { Text(label) }
                )
            }
        }
    }) { pad ->
        NavHost(nav, "home", Modifier.padding(pad)) {
            composable("home") { Home(db) }
            composable("female") { Rabbits(db, "Indukan") }
            composable("male") { Rabbits(db, "Pejantan") }
            composable("mating") { Matings(db) }
        }
    }
}

@Composable fun Home(db: AppDatabase) {
    val a by db.rabbitDao().countAll().collectAsState(0)
    val b by db.rabbitDao().countFemale().collectAsState(0)
    val c by db.rabbitDao().countMale().collectAsState(0)
    val d by db.matingDao().countAll().collectAsState(0)
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { Text("🐇 Data Kelinci", style=MaterialTheme.typography.headlineMedium); Text("Dashboard peternakan") }
        item { Stat("Total kelinci", a) }; item { Stat("Total indukan", b) }; item { Stat("Total pejantan", c) }; item { Stat("Total perkawinan", d) }
    }
}
@Composable fun Stat(t:String,n:Int) { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) { Text(t); Text("$n", style=MaterialTheme.typography.headlineLarge) } } }

@Composable fun Rabbits(db: AppDatabase, gender:String) {
    val scope=rememberCoroutineScope(); val list by db.rabbitDao().byGender(gender).collectAsState(emptyList())
    var q by remember{mutableStateOf("")}; var add by remember{mutableStateOf(false)}
    val shown=list.filter{q.isBlank() || it.name.contains(q,true) || it.rabbitId.contains(q,true) || it.breed.contains(q,true)}
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(gender, style=MaterialTheme.typography.headlineMedium)
        OutlinedTextField(q,{q=it},Modifier.fillMaxWidth(),label={Text("Cari")})
        Spacer(Modifier.height(8.dp)); Button({add=true},Modifier.fillMaxWidth()){Text("Tambah $gender")}
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) { items(shown,key={it.id}) { r ->
            Card(Modifier.fillMaxWidth()){ Column(Modifier.padding(14.dp)){
                Text("${r.name} (${r.rabbitId})",style=MaterialTheme.typography.titleLarge)
                Text("Ras: ${r.breed}  •  Warna: ${r.color}"); Text("Lahir: ${r.birthDate}  •  Status: ${r.status}")
                if(r.notes.isNotBlank()) Text("Catatan: ${r.notes}")
                TextButton({scope.launch{db.rabbitDao().delete(r)}}){Text("Hapus")}
            }}
        }}
    }
    if(add) RabbitDialog(gender,{add=false}){scope.launch{db.rabbitDao().insert(it)};add=false}
}

@Composable fun RabbitDialog(gender:String,onDismiss:()->Unit,onSave:(Rabbit)->Unit) {
    var id by remember{mutableStateOf("")}; var name by remember{mutableStateOf("")}; var breed by remember{mutableStateOf("")}
    var color by remember{mutableStateOf("")}; var birth by remember{mutableStateOf("")}; var status by remember{mutableStateOf("Aktif")}; var notes by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=onDismiss,title={Text("Tambah $gender")},text={
        Column(verticalArrangement=Arrangement.spacedBy(5.dp)){
            Field("ID",id){id=it}; Field("Nama",name){name=it}; Field("Ras",breed){breed=it}; Field("Warna",color){color=it}
            Field("Tanggal lahir",birth){birth=it}; Field("Status",status){status=it}; Field("Catatan",notes){notes=it}
        }
    },confirmButton={Button(enabled=id.isNotBlank()&&name.isNotBlank(),onClick={onSave(Rabbit(rabbitId=id,name=name,breed=breed,color=color,birthDate=birth,status=status,notes=notes,gender=gender))}){Text("Simpan")}},
    dismissButton={TextButton(onDismiss){Text("Batal")}})
}
@Composable fun Field(l:String,v:String,on:(String)->Unit)=OutlinedTextField(v,on,Modifier.fillMaxWidth(),label={Text(l)},singleLine=true)

@Composable fun Matings(db:AppDatabase) {
    val scope=rememberCoroutineScope(); val ms by db.matingDao().all().collectAsState(emptyList())
    Column(Modifier.fillMaxSize().padding(16.dp)){ Text("Perkawinan",style=MaterialTheme.typography.headlineMedium)
        Button({scope.launch{db.matingDao().insert(Mating(femaleId=0,maleId=0,matingDate="",expectedBirth="",offspringCount=0,status="Direncanakan",notes=""))}},Modifier.fillMaxWidth()){Text("Tambah perkawinan")}
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(ms,key={it.id}){m->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text("Riwayat perkawinan #${m.id}",style=MaterialTheme.typography.titleLarge);Text("Status: ${m.status}");TextButton({scope.launch{db.matingDao().delete(m)}}){Text("Hapus")}}}}}
    }
}
