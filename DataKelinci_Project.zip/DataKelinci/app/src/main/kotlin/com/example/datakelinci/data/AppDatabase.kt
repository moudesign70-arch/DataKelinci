package com.example.datakelinci.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities=[Rabbit::class, Mating::class], version=1, exportSchema=false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun rabbitDao(): RabbitDao
    abstract fun matingDao(): MatingDao
    companion object {
        @Volatile private var instance: AppDatabase? = null
        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "data_kelinci.db").build().also { instance = it }
        }
    }
}
