package com.example.datakelinci.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "rabbits")
data class Rabbit(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val rabbitId: String, val name: String, val breed: String, val color: String,
    val birthDate: String, val status: String, val notes: String, val gender: String
)

@Entity(tableName = "matings")
data class Mating(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val femaleId: Long, val maleId: Long, val matingDate: String,
    val expectedBirth: String, val offspringCount: Int, val status: String, val notes: String
)
